const EASTERN_TZ = "America/New_York";

function getEasternDateParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: EASTERN_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(date);

  return Object.fromEntries(
    parts.filter(p => p.type !== "literal").map(p => [p.type, p.value])
  );
}

function updateEasternClock() {
  const now = new Date();

  const timeParts = new Intl.DateTimeFormat("en-GB", {
    timeZone: EASTERN_TZ,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).formatToParts(now);

  const t = Object.fromEntries(
    timeParts.filter(p => p.type !== "literal").map(p => [p.type, p.value])
  );

  const clock = document.getElementById("clock") || document.getElementById("time");
  if (clock) {
    clock.innerHTML = `${t.hour}:${t.minute}:<span class="seconds">${t.second}</span>`;
  }

  const dateElement = document.getElementById("date");
  if (dateElement) {
    const hebrewDate = new Intl.DateTimeFormat("he-u-ca-hebrew", {
      timeZone: EASTERN_TZ,
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(now);

    const englishDate = new Intl.DateTimeFormat("en-US", {
      timeZone: EASTERN_TZ,
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric"
    }).format(now);

    dateElement.textContent = `${hebrewDate} | ${englishDate}`;
  }
}

async function updateWeeklyParasha() {
  const parashaElement =
    document.getElementById("parasha") ||
    document.getElementById("parashaName");

  if (!parashaElement) return;

  parashaElement.textContent = "טוען פרשת השבוע...";

  const { year, month, day } = getEasternDateParts();

  const url =
    `https://www.hebcal.com/shabbat?cfg=json` +
    `&gy=${year}&gm=${month}&gd=${day}` +
    `&latitude=40.7062&longitude=-73.3062` +
    `&tzid=${encodeURIComponent(EASTERN_TZ)}` +
    `&lg=h&i=off`;

  try {
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) throw new Error(`Hebcal returned ${response.status}`);

    const data = await response.json();
    const item = (data.items || []).find(entry =>
      entry.category === "parashat" ||
      String(entry.hebrew || "").includes("פרשת") ||
      String(entry.title || "").toLowerCase().includes("parashat")
    );

    if (!item) throw new Error("No parashah found");

    let name = item.hebrew || item.title || "";
    name = name
      .replace(/^Parashat\s+/i, "")
      .replace(/^פרשת\s+/, "")
      .trim();

    parashaElement.textContent = `פרשת ${name}`;
  } catch (error) {
    console.error("Could not update parashah:", error);
    parashaElement.textContent = "פרשת השבוע — לא ניתן לעדכן";
  }
}

function startBoardFix() {
  updateEasternClock();
  updateWeeklyParasha();
  setInterval(updateEasternClock, 1000);
  setInterval(updateWeeklyParasha, 60 * 60 * 1000);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startBoardFix);
} else {
  startBoardFix();
}